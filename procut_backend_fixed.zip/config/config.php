<?php
/**
 * ProCut Application & Security Configuration
 */

// Ensure output buffering is active early to prevent headers-already-sent issues
if (!ob_get_level()) {
    @ob_start();
}

// Error Reporting & Diagnostics
// Suppress display of errors in production to prevent layout breakage & header corruption
$hostHeader = $_SERVER['HTTP_HOST'] ?? '';
$isLocalhost = in_array($hostHeader, ['localhost', '127.0.0.1', 'localhost:5050', '127.0.0.1:5050'])
    || str_starts_with($hostHeader, 'localhost:')
    || str_starts_with($hostHeader, '127.0.0.1:');

if ($isLocalhost) {
    ini_set('display_errors', '1');
    ini_set('display_startup_errors', '1');
} else {
    ini_set('display_errors', '0');
    ini_set('display_startup_errors', '0');
}
error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);

// Timezone
date_default_timezone_set('UTC');

// ============================================================
// Database Connection Settings
// ============================================================
// For local development: use 127.0.0.1, user 'root', empty password.
// For InfinityFree: replace with values from your "Manage procut.free.nf" tab!
define('DB_HOST', '127.0.0.1'); // InfinityFree MySQL Host (e.g. sql308.infinityfree.com)
define('DB_PORT', '3306');
define('DB_NAME', 'procut_db'); // InfinityFree DB Name (e.g. epiz_xxxxxxx_procut_db)
define('DB_USER', 'root');      // InfinityFree Username (e.g. epiz_xxxxxxx)
define('DB_PASS', '');          // InfinityFree vPanel Account Password

// Paths
define('BASE_PATH', dirname(__DIR__));
define('UPLOAD_DIR', BASE_PATH . '/uploads');
define('MEDIA_UPLOAD_DIR', UPLOAD_DIR . '/media');
define('THUMBNAIL_UPLOAD_DIR', UPLOAD_DIR . '/thumbnails');
define('MUSIC_UPLOAD_DIR', UPLOAD_DIR . '/music');
define('STICKER_UPLOAD_DIR', UPLOAD_DIR . '/stickers');

// Ensure upload directories exist
foreach ([UPLOAD_DIR, MEDIA_UPLOAD_DIR, THUMBNAIL_UPLOAD_DIR, MUSIC_UPLOAD_DIR, STICKER_UPLOAD_DIR] as $dir) {
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
}

// Session Security Configuration
define('SESSION_LIFETIME', 1800); // 30 minutes inactivity timeout
define('TOKEN_LIFETIME_DAYS', 30); // 30 days token expiry for mobile app
define('ADMIN_SESSION_KEY', 'procut_admin_session');

// App Info
define('APP_NAME', 'ProCut');
define('APP_VERSION', '1.0.0');

// Base URL detection
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https')
    || (!empty($_SERVER['HTTP_X_FORWARDED_SSL']) && strtolower($_SERVER['HTTP_X_FORWARDED_SSL']) === 'on')
    || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443);
$protocol = $isHttps ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost:5050';
define('APP_BASE_URL', "{$protocol}://{$host}");

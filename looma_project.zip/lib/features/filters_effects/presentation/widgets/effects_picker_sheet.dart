import 'package:flutter/material.dart';
import '../../../../app/theme/app_typography.dart';
import '../../../../core/widgets/looma_slider.dart';
import '../../domain/entities/video_effect_type.dart';

class EffectsPickerSheet extends StatefulWidget {
  final VideoEffectType selectedEffect;
  final double effectIntensity;
  final double initialBlur;
  final double initialZoom;
  final int initialFadeInMs;
  final int initialFadeOutMs;
  final double initialBrightness;
  final double initialContrast;
  final double initialSaturation;
  final Function(VideoEffectType effect) onEffectSelected;
  final Function(double intensity)? onIntensityChanged;
  final Function({
    required double blur,
    required double zoom,
    required int fadeInMs,
    required int fadeOutMs,
    required double brightness,
    required double contrast,
    required double saturation,
  }) onEffectsChanged;

  const EffectsPickerSheet({
    super.key,
    this.selectedEffect = VideoEffectType.none,
    this.effectIntensity = 1.0,
    required this.initialBlur,
    required this.initialZoom,
    required this.initialFadeInMs,
    required this.initialFadeOutMs,
    required this.initialBrightness,
    required this.initialContrast,
    required this.initialSaturation,
    required this.onEffectSelected,
    this.onIntensityChanged,
    required this.onEffectsChanged,
  });

  @override
  State<EffectsPickerSheet> createState() => _EffectsPickerSheetState();
}

class _EffectsPickerSheetState extends State<EffectsPickerSheet> {
  late VideoEffectType _activeEffect;
  late double _intensity;
  VideoEffectCategory _selectedCategory = VideoEffectCategory.trending;
  final TextEditingController _searchController = TextEditingController();
  bool _showAdvancedTuning = false;

  late double _blur;
  late double _zoom;
  late double _fadeInSec;
  late double _fadeOutSec;
  late double _brightness;
  late double _contrast;
  late double _saturation;

  @override
  void initState() {
    super.initState();
    _activeEffect = widget.selectedEffect;
    _intensity = widget.effectIntensity;
    _blur = widget.initialBlur;
    _zoom = widget.initialZoom;
    _fadeInSec = widget.initialFadeInMs / 1000.0;
    _fadeOutSec = widget.initialFadeOutMs / 1000.0;
    _brightness = widget.initialBrightness;
    _contrast = widget.initialContrast;
    _saturation = widget.initialSaturation;
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSelectEffect(VideoEffectType effect) {
    setState(() => _activeEffect = effect);
    widget.onEffectSelected(effect);
  }

  void _notifyAdvancedChanges() {
    widget.onEffectsChanged(
      blur: _blur,
      zoom: _zoom,
      fadeInMs: (_fadeInSec * 1000).round(),
      fadeOutMs: (_fadeOutSec * 1000).round(),
      brightness: _brightness,
      contrast: _contrast,
      saturation: _saturation,
    );
  }

  List<VideoEffectType> _getFilteredEffects() {
    final query = _searchController.text.trim().toLowerCase();
    return VideoEffectType.values.where((e) {
      if (e == VideoEffectType.none) return false;
      if (query.isNotEmpty) {
        return e.label.toLowerCase().contains(query) || e.description.toLowerCase().contains(query);
      }
      return e.category == _selectedCategory;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final filteredEffects = _getFilteredEffects();
    final query = _searchController.text.trim();

    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.75,
      ),
      decoration: const BoxDecoration(
        color: Color(0xFF14161E),
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Drag handle pill
          Container(
            width: 36,
            height: 4,
            margin: const EdgeInsets.only(top: 8, bottom: 4),
            decoration: BoxDecoration(
              color: Colors.white24,
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // 1. CapCut-style Search Bar & Dismiss Chevron
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    height: 38,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF222530),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.search, size: 18, color: Color(0xFF8E95A5)),
                        const SizedBox(width: 8),
                        Expanded(
                          child: TextField(
                            controller: _searchController,
                            onChanged: (_) => setState(() {}),
                            style: const TextStyle(color: Colors.white, fontSize: 13),
                            decoration: const InputDecoration(
                              hintText: 'People are searching oblique blur, flash...',
                              hintStyle: TextStyle(color: Color(0xFF757C8E), fontSize: 13),
                              border: InputBorder.none,
                              isDense: true,
                              contentPadding: EdgeInsets.zero,
                            ),
                          ),
                        ),
                        if (query.isNotEmpty)
                          GestureDetector(
                            onTap: () => setState(() => _searchController.clear()),
                            child: const Icon(Icons.close, size: 16, color: Color(0xFF8E95A5)),
                          ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.keyboard_arrow_down, color: Colors.white70, size: 26),
                  tooltip: 'Close',
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ],
            ),
          ),

          // 2. Category Tabs (Saved Icon + Trending, Classic, NEW, Hits, etc.)
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            physics: const BouncingScrollPhysics(),
            child: Row(
              children: [
                // Bookmark / Saved icon button
                InkWell(
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('✨ Favorite effects saved to your personal library!'),
                        duration: Duration(seconds: 1),
                        backgroundColor: Color(0xFF222530),
                      ),
                    );
                  },
                  borderRadius: BorderRadius.circular(8),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                    margin: const EdgeInsets.only(right: 6),
                    child: const Icon(Icons.bookmark_border, size: 18, color: Colors.white70),
                  ),
                ),

                // Category items
                ...VideoEffectCategory.values.map((cat) {
                  final isSelected = _selectedCategory == cat && query.isEmpty;
                  return GestureDetector(
                    onTap: () {
                      _searchController.clear();
                      setState(() => _selectedCategory = cat);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            cat.label,
                            style: TextStyle(
                              color: isSelected ? Colors.white : const Color(0xFF8E95A5),
                              fontSize: 13,
                              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                            ),
                          ),
                          const SizedBox(height: 4),
                          // Cyan active indicator line
                          Container(
                            height: 2,
                            width: isSelected ? 22 : 0,
                            decoration: BoxDecoration(
                              color: const Color(0xFF00C2CB),
                              borderRadius: BorderRadius.circular(1),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
              ],
            ),
          ),

          const Divider(color: Color(0xFF222530), height: 1),

          // 3. Live Intensity / Tuning Controls Bar if effect is active
          if (_activeEffect != VideoEffectType.none)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              color: const Color(0xFF1B1E28),
              child: Row(
                children: [
                  Icon(_activeEffect.icon, size: 16, color: const Color(0xFF00C2CB)),
                  const SizedBox(width: 6),
                  Flexible(
                    child: Text(
                      _activeEffect.label,
                      style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        trackHeight: 3,
                        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                        activeTrackColor: const Color(0xFF00C2CB),
                        inactiveTrackColor: const Color(0xFF2C2F38),
                        thumbColor: Colors.white,
                      ),
                      child: Slider(
                        value: _intensity.clamp(0.0, 1.0),
                        min: 0.0,
                        max: 1.0,
                        onChanged: (v) {
                          setState(() => _intensity = v);
                          widget.onIntensityChanged?.call(v);
                        },
                      ),
                    ),
                  ),
                  Text(
                    '${(_intensity * 100).round()}%',
                    style: const TextStyle(color: Color(0xFF00C2CB), fontSize: 11, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(width: 4),
                  IconButton(
                    icon: Icon(
                      _showAdvancedTuning ? Icons.tune : Icons.tune_outlined,
                      size: 16,
                      color: _showAdvancedTuning ? const Color(0xFF00C2CB) : Colors.white70,
                    ),
                    tooltip: 'Fine Adjustments',
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(minWidth: 24, minHeight: 24),
                    onPressed: () => setState(() => _showAdvancedTuning = !_showAdvancedTuning),
                  ),
                ],
              ),
            ),

          // 4. Effects 4-Column Grid
          Expanded(
            child: _showAdvancedTuning
                ? _buildAdvancedTuningView()
                : GridView.builder(
                    padding: const EdgeInsets.all(12),
                    physics: const BouncingScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 10,
                      childAspectRatio: 0.76,
                    ),
                    itemCount: filteredEffects.length + 1,
                    itemBuilder: (context, index) {
                      // First item is always "None"
                      if (index == 0) {
                        final isNoneSelected = _activeEffect == VideoEffectType.none;
                        return _buildEffectCard(
                          effect: VideoEffectType.none,
                          isSelected: isNoneSelected,
                          onTap: () => _onSelectEffect(VideoEffectType.none),
                        );
                      }

                      final effect = filteredEffects[index - 1];
                      final isSelected = _activeEffect == effect;

                      return _buildEffectCard(
                        effect: effect,
                        isSelected: isSelected,
                        onTap: () => _onSelectEffect(effect),
                      );
                    },
                  ),
          ),

          // Bottom Quick Check Bar
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: const BoxDecoration(
              color: Color(0xFF101117),
              border: Border(top: BorderSide(color: Color(0xFF1E2028))),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.check_circle_outline, size: 16, color: Color(0xFF00C2CB)),
                    const SizedBox(width: 6),
                    Text(
                      _activeEffect == VideoEffectType.none ? 'Original (No Effect)' : 'Applied: ${_activeEffect.label}',
                      style: const TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                  ],
                ),
                ElevatedButton(
                  onPressed: () => Navigator.of(context).pop(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00C2CB),
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    elevation: 0,
                  ),
                  child: const Text('Done', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEffectCard({
    required VideoEffectType effect,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    final isNone = effect == VideoEffectType.none;

    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Visual thumbnail card
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                gradient: isNone
                    ? null
                    : LinearGradient(
                        colors: [effect.color1, effect.color2],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                color: isNone ? const Color(0xFF222530) : null,
                border: Border.all(
                  color: isSelected ? const Color(0xFF00C2CB) : Colors.white12,
                  width: isSelected ? 2.5 : 1.0,
                ),
                boxShadow: isSelected
                    ? [
                        BoxShadow(
                          color: const Color(0xFF00C2CB).withValues(alpha: 0.4),
                          blurRadius: 10,
                          spreadRadius: 1,
                        ),
                      ]
                    : null,
              ),
              clipBehavior: Clip.antiAlias,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  // Center Icon or Symbol
                  Center(
                    child: Icon(
                      effect.icon,
                      size: isNone ? 28 : 26,
                      color: Colors.white,
                    ),
                  ),

                  // Top-Left download badge (like in CapCut Image 2)
                  if (!isNone)
                    Positioned(
                      top: 4,
                      left: 4,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.4),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.arrow_downward, size: 10, color: Colors.white),
                      ),
                    ),

                  // Selection active check badge
                  if (isSelected)
                    Positioned(
                      bottom: 4,
                      right: 4,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: const BoxDecoration(
                          color: Color(0xFF00C2CB),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.check, size: 10, color: Colors.black),
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 5),

          // Label
          Text(
            effect.label,
            style: TextStyle(
              color: isSelected ? const Color(0xFF00C2CB) : Colors.white70,
              fontSize: 10.5,
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildAdvancedTuningView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Fine Tune Effect Parameters', style: AppTypography.titleSmall),
              TextButton(
                onPressed: () => setState(() => _showAdvancedTuning = false),
                child: const Text('Back to Grid', style: TextStyle(color: Color(0xFF00C2CB), fontSize: 12)),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Blur
          LoomaSlider(
            label: 'Gaussian Blur',
            icon: Icons.blur_on,
            value: _blur,
            min: 0.0,
            max: 10.0,
            divisions: 20,
            valueFormatter: (v) => '${v.toStringAsFixed(1)}px',
            onChanged: (v) {
              setState(() => _blur = v);
              _notifyAdvancedChanges();
            },
          ),
          const SizedBox(height: 10),

          // Zoom
          LoomaSlider(
            label: 'Zoom Scale',
            icon: Icons.zoom_in,
            value: _zoom,
            min: 1.0,
            max: 2.0,
            divisions: 20,
            valueFormatter: (v) => '${v.toStringAsFixed(2)}x',
            onChanged: (v) {
              setState(() => _zoom = v);
              _notifyAdvancedChanges();
            },
          ),
          const SizedBox(height: 10),

          // Brightness
          LoomaSlider(
            label: 'Brightness',
            icon: Icons.wb_sunny_outlined,
            value: _brightness,
            min: -0.5,
            max: 0.5,
            divisions: 20,
            valueFormatter: (v) => '${(v * 100).round()}%',
            onChanged: (v) {
              setState(() => _brightness = v);
              _notifyAdvancedChanges();
            },
          ),
          const SizedBox(height: 10),

          // Contrast
          LoomaSlider(
            label: 'Contrast',
            icon: Icons.contrast,
            value: _contrast,
            min: 0.5,
            max: 1.8,
            divisions: 20,
            valueFormatter: (v) => '${v.toStringAsFixed(2)}x',
            onChanged: (v) {
              setState(() => _contrast = v);
              _notifyAdvancedChanges();
            },
          ),
        ],
      ),
    );
  }
}

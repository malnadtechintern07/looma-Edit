import 'package:flutter/material.dart';

enum VideoEffectCategory {
  trending('Trending'),
  classic('Classic'),
  newHits('NEW'),
  hits('Hits'),
  introOutro('Intro & Outro'),
  bodyEffects('Body Effects'),
  atmosphere('Atmosphere');

  final String label;
  const VideoEffectCategory(this.label);
}

enum VideoEffectType {
  none(
    label: 'None',
    category: VideoEffectCategory.trending,
    description: 'No effect applied',
    icon: Icons.block,
    color1: Color(0xFF2C2F38),
    color2: Color(0xFF1E2028),
  ),
  explosion(
    label: 'Explosion',
    category: VideoEffectCategory.trending,
    description: 'Fiery gold shockwave particle blast',
    icon: Icons.local_fire_department,
    color1: Color(0xFFFF9900),
    color2: Color(0xFFFF3300),
  ),
  superLarge(
    label: 'Super-large..',
    category: VideoEffectCategory.trending,
    description: 'Cinematic breathing zoom with atmospheric bloom',
    icon: Icons.zoom_out_map,
    color1: Color(0xFF00C6FF),
    color2: Color(0xFF0072FF),
  ),
  rollingFilm(
    label: 'Rolling Film',
    category: VideoEffectCategory.trending,
    description: 'Vintage 35mm film sprockets with rolling scanlines',
    icon: Icons.movie_filter,
    color1: Color(0xFF434343),
    color2: Color(0xFF000000),
  ),
  flash(
    label: 'Flash',
    category: VideoEffectCategory.trending,
    description: 'High-speed luminous white strobe pulse',
    icon: Icons.flash_on,
    color1: Color(0xFFFF007A),
    color2: Color(0xFFFF5E36),
  ),
  blackFlash2(
    label: 'Black Flash 2',
    category: VideoEffectCategory.trending,
    description: 'Rhythmic dark strobe pulse beat',
    icon: Icons.dark_mode,
    color1: Color(0xFF8E2DE2),
    color2: Color(0xFF4A00E0),
  ),
  fadeIn(
    label: 'Fade In',
    category: VideoEffectCategory.introOutro,
    description: 'Cinematic soft luminance fade entrance',
    icon: Icons.gradient,
    color1: Color(0xFFF7971E),
    color2: Color(0xFFFFD200),
  ),
  shake(
    label: 'Shake',
    category: VideoEffectCategory.trending,
    description: 'Vibrant dynamic camera jitter shake',
    icon: Icons.vibration,
    color1: Color(0xFFE52D27),
    color2: Color(0xFFB31217),
  ),
  glitch(
    label: 'RGB Glitch',
    category: VideoEffectCategory.newHits,
    description: 'Chromatic aberration slice and digital glitch',
    icon: Icons.broken_image,
    color1: Color(0xFF00F2FE),
    color2: Color(0xFF4FACFE),
  ),
  neonGlow(
    label: 'Neon Glow',
    category: VideoEffectCategory.classic,
    description: 'Cyberpunk edge luminescent neon shine',
    icon: Icons.auto_awesome,
    color1: Color(0xFFB92B27),
    color2: Color(0xFF1565C0),
  ),
  retroVhs(
    label: 'Retro VHS',
    category: VideoEffectCategory.classic,
    description: '90s CRT scanlines with VHS tracking distortion',
    icon: Icons.videocam,
    color1: Color(0xFF654EA3),
    color2: Color(0xFFEAAFC8),
  ),
  sparkles(
    label: 'Sparkles',
    category: VideoEffectCategory.hits,
    description: 'Glittering starlight sparkle particles',
    icon: Icons.star_half,
    color1: Color(0xFFFDC830),
    color2: Color(0xFFF37335),
  ),
  heartFloat(
    label: 'Heart Float',
    category: VideoEffectCategory.hits,
    description: 'Romantic rising heart particles',
    icon: Icons.favorite,
    color1: Color(0xFFFF416C),
    color2: Color(0xFFFF4B2B),
  ),
  kaleidoscope(
    label: 'Prism Mirror',
    category: VideoEffectCategory.atmosphere,
    description: 'Multi-angle kaleidoscope mirror reflection',
    icon: Icons.blur_linear,
    color1: Color(0xFF3A1C71),
    color2: Color(0xFFD76D77),
  ),
  heartbeatZoom(
    label: 'Beat Pulse',
    category: VideoEffectCategory.bodyEffects,
    description: 'Rhythmic bass-drop camera heartbeat zoom',
    icon: Icons.hearing,
    color1: Color(0xFF11998E),
    color2: Color(0xFF38EF7D),
  );

  final String label;
  final VideoEffectCategory category;
  final String description;
  final IconData icon;
  final Color color1;
  final Color color2;

  const VideoEffectType({
    required this.label,
    required this.category,
    required this.description,
    required this.icon,
    required this.color1,
    required this.color2,
  });

  static VideoEffectType fromString(String? val) {
    return VideoEffectType.values.firstWhere(
      (e) => e.name == val,
      orElse: () => VideoEffectType.none,
    );
  }
}

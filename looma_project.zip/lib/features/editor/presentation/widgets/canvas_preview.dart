import 'dart:io';
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../../../../app/theme/app_colors.dart';
import '../../../../app/theme/app_typography.dart';
import '../../../../core/utils/timecode_formatter.dart';
import '../../../editor/domain/entities/transition_type.dart';
import '../../../filters_effects/domain/entities/filter_preset.dart';
import '../../../filters_effects/domain/entities/video_effect_type.dart';
import '../../../text_stickers/domain/entities/overlay_animation_type.dart';
import '../../../text_stickers/domain/entities/sticker_overlay_entity.dart';
import '../../../text_stickers/domain/entities/text_overlay_entity.dart';
import '../../../text_stickers/presentation/widgets/text_editor_sheet.dart';
import '../../domain/entities/timeline_state.dart';
import '../../domain/entities/video_clip_entity.dart';
import '../providers/editor_controller.dart';

class CanvasPreview extends StatefulWidget {
  final TimelineState timelineState;
  final EditorController controller;

  const CanvasPreview({
    super.key,
    required this.timelineState,
    required this.controller,
  });

  @override
  State<CanvasPreview> createState() => _CanvasPreviewState();
}

class _CanvasPreviewState extends State<CanvasPreview> {
  bool _showSafeMargins = false;

  // Single Active Video Player Controller & Preload Cache (max 2 entries to prevent GPU exhaustion)
  final Map<String, VideoPlayerController> _videoControllers = {};
  String? _currentPlayingPath;
  bool _wasPlaying = false;
  int _lastSeekTargetMs = -1;

  // Interactive Gesture State for Manual Video Clip Manipulation
  double _baseZoomScale = 1.0;
  double _basePositionX = 0.0;
  double _basePositionY = 0.0;
  double _baseRotation = 0.0;

  // Interactive Gesture State for Manual Text Overlay Manipulation
  double _baseTextPosX = 0.5;
  double _baseTextPosY = 0.5;
  double _baseTextScale = 1.0;
  double _baseTextRotation = 0.0;

  @override
  void initState() {
    super.initState();
    _syncActiveVideoController();
  }

  @override
  void didUpdateWidget(covariant CanvasPreview oldWidget) {
    super.didUpdateWidget(oldWidget);
    _syncActiveVideoController();
  }

  @override
  void dispose() {
    for (final controller in _videoControllers.values) {
      try {
        controller.pause();
        controller.dispose();
      } catch (_) {}
    }
    _videoControllers.clear();
    super.dispose();
  }

  bool _isVideoFile(String path) {
    final lower = path.toLowerCase();
    return lower.endsWith('.mp4') ||
        lower.endsWith('.mov') ||
        lower.endsWith('.mkv') ||
        lower.endsWith('.webm') ||
        lower.endsWith('.avi') ||
        lower.endsWith('.3gp') ||
        lower.endsWith('.m4v');
  }

  VideoPlayerController? _getVideoController(String path, {String? clipId}) {
    if (!_isVideoFile(path)) return null;

    if (_videoControllers.containsKey(path)) {
      return _videoControllers[path];
    }

    // Keep cache size strictly at max 2 to prevent GPU/SurfaceView memory exhaustion
    if (_videoControllers.length >= 2) {
      final keyToRemove = _videoControllers.keys.firstWhere(
        (k) => k != _currentPlayingPath,
        orElse: () => _videoControllers.keys.first,
      );
      final old = _videoControllers.remove(keyToRemove);
      try {
        old?.pause();
        old?.dispose();
      } catch (_) {}
    }

    try {
      VideoPlayerController controller;
      if (path.startsWith('assets/')) {
        controller = VideoPlayerController.asset(path);
      } else if (File(path).existsSync()) {
        controller = VideoPlayerController.file(File(path));
      } else {
        return null;
      }

      _videoControllers[path] = controller;
      controller.initialize().then((_) {
        controller.setLooping(false);
        final realDurMs = controller.value.duration.inMilliseconds;
        if (clipId != null && realDurMs > 0) {
          widget.controller.syncClipRealDuration(clipId, realDurMs);
        }
        if (mounted) {
          setState(() {});
          _syncActiveVideoController();
        }
      }).catchError((e) {
        debugPrint('CanvasPreview: failed to initialize VideoPlayerController for $path: $e');
      });
      return controller;
    } catch (_) {
      return null;
    }
  }

  void _syncActiveVideoController() {
    final activeClip = widget.timelineState.activeVideoClip;
    final isPlaying = widget.timelineState.isPlaying;
    final currentPosMs = widget.timelineState.playheadPositionMs;

    if (activeClip == null || !_isVideoFile(activeClip.mediaPath)) {
      for (final c in _videoControllers.values) {
        if (c.value.isPlaying) c.pause();
      }
      _currentPlayingPath = null;
      _wasPlaying = isPlaying;
      return;
    }

    final path = activeClip.mediaPath;
    final controller = _getVideoController(path, clipId: activeClip.id);
    if (controller == null || !controller.value.isInitialized) {
      _wasPlaying = isPlaying;
      return;
    }

    // Pause any non-active background controller
    for (final entry in _videoControllers.entries) {
      if (entry.key != path && entry.value.value.isPlaying) {
        entry.value.pause();
      }
    }

    final offsetInClipMs = (currentPosMs - activeClip.timelineStartMs + activeClip.trimStartMs)
        .clamp(0, activeClip.sourceDurationMs);
    final targetDuration = Duration(milliseconds: offsetInClipMs);
    final currentVideoMs = controller.value.position.inMilliseconds;
    final hasSwitchedClip = _currentPlayingPath != path;
    final hasPlayStateChanged = _wasPlaying != isPlaying;

    _currentPlayingPath = path;
    _wasPlaying = isPlaying;

    if (isPlaying) {
      // If we just toggled play, switched clips, or had a big user jump (> 1200ms), seek once
      final isDislocated = (currentVideoMs - offsetInClipMs).abs() > 1200;
      if (hasPlayStateChanged || hasSwitchedClip || isDislocated) {
        controller.seekTo(targetDuration);
      }

      if (!controller.value.isPlaying) {
        controller.play();
      }
      controller.setPlaybackSpeed(activeClip.speed.clamp(0.25, 4.0));
      controller.setVolume(activeClip.volume.clamp(0.0, 1.0));
    } else {
      // When paused or scrubbing, pause video and seek precisely to the current playhead frame
      if (controller.value.isPlaying) {
        controller.pause();
      }
      if ((currentVideoMs - offsetInClipMs).abs() > 40 && _lastSeekTargetMs != offsetInClipMs) {
        _lastSeekTargetMs = offsetInClipMs;
        controller.seekTo(targetDuration);
      }
    }
  }

  void _openTextEditor(TextOverlayEntity textItem) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => TextEditorSheet(
        initialText: textItem,
        onSave: ({
          required text,
          required fontFamily,
          required fontSize,
          required colorHex,
          backgroundColorHex,
          required animationType,
        }) {
          widget.controller.updateTextOverlay(
            textItem.copyWith(
              text: text,
              fontFamily: fontFamily,
              fontSize: fontSize,
              colorHex: colorHex,
              backgroundColorHex: backgroundColorHex,
              animationType: animationType,
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = widget.timelineState;
    final project = state.project;
    final activeClip = state.activeVideoClip;
    final isClipSelected = state.selectionType == SelectionType.videoClip &&
        state.selectedItemId == activeClip?.id;
    final isTextSelected = state.selectionType == SelectionType.textOverlay;
    final currentPosMs = state.playheadPositionMs;
    final totalDurationMs = project.calculatedDurationMs;

    // Filter active text overlays
    final activeTexts = project.textOverlays.where((t) {
      return currentPosMs >= t.timelineStartMs && currentPosMs <= t.timelineEndMs;
    }).toList();

    // Filter active sticker overlays
    final activeStickers = project.stickerOverlays.where((s) {
      return currentPosMs >= s.timelineStartMs && currentPosMs <= s.timelineEndMs;
    }).toList();

    return Container(
      color: Colors.black,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Centered Aspect Ratio Preview Canvas
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: AspectRatio(
                aspectRatio: project.aspectRatio.ratio,
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final canvasWidth = constraints.maxWidth;
                    final canvasHeight = constraints.maxHeight;

                    return Container(
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                        color: const Color(0xFF111318),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: isClipSelected
                              ? AppColors.primary
                              : (isTextSelected ? AppColors.textTrack : AppColors.surfaceBorder),
                          width: (isClipSelected || isTextSelected) ? 2.5 : 1.5,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: isClipSelected
                                ? AppColors.primary.withValues(alpha: 0.35)
                                : (isTextSelected
                                    ? AppColors.textTrack.withValues(alpha: 0.35)
                                    : AppColors.primary.withValues(alpha: 0.15)),
                            blurRadius: (isClipSelected || isTextSelected) ? 24 : 20,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () {
                          if (activeClip != null) {
                            widget.controller.setSelection(SelectionType.videoClip, activeClip.id);
                          }
                        },
                        onScaleStart: (details) {
                          if (activeClip != null) {
                            _baseZoomScale = activeClip.zoomScale;
                            _basePositionX = activeClip.positionX;
                            _basePositionY = activeClip.positionY;
                            _baseRotation = activeClip.rotationDegrees;
                          }
                        },
                        onScaleUpdate: (details) {
                          if (activeClip != null) {
                            final newZoom = (_baseZoomScale * details.scale).clamp(0.2, 5.0);
                            final newX = _basePositionX + details.focalPointDelta.dx;
                            final newY = _basePositionY + details.focalPointDelta.dy;
                            final newRot = (_baseRotation + (details.rotation * (180 / 3.14159))) % 360;

                            widget.controller.updateClipTransform(
                              clipId: activeClip.id,
                              zoomScale: newZoom,
                              positionX: newX,
                              positionY: newY,
                              rotationDegrees: newRot,
                            );
                          }
                        },
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            // Video Frame / Player Rendering Layer
                            if (activeClip != null)
                              _buildVideoClipFrame(activeClip, currentPosMs, isClipSelected)
                            else
                              _buildEmptyCanvasPlaceholder(),

                            // Transform Selection Bounding Box & Corner Handles for Video Clip
                            if (isClipSelected && activeClip != null) ...[
                              _buildSelectionTransformHandles(activeClip),
                              _buildClipQuickToolbar(activeClip),
                            ],

                            // Safe Margins Guide
                            if (_showSafeMargins) _buildSafeMarginsGuide(),

                            // Text Overlays Layer with Interactive Positioning & Gestures
                            ...activeTexts.map((textEntity) {
                              final isThisTextSelected = state.selectionType == SelectionType.textOverlay &&
                                  state.selectedItemId == textEntity.id;
                              return _buildInteractiveTextOverlay(
                                textEntity: textEntity,
                                currentPosMs: currentPosMs,
                                isSelected: isThisTextSelected,
                                canvasWidth: canvasWidth,
                                canvasHeight: canvasHeight,
                              );
                            }),

                            // Sticker Overlays Layer
                            ...activeStickers.map((stickerEntity) {
                              return _buildStickerOverlay(stickerEntity);
                            }),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),

          // Top Info Bar (Timecode, Safe Margin Toggle, & Full Screen Button)
          Positioned(
            top: 8,
            left: 16,
            right: 16,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Live SMPTE Timecode
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.7),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: Text(
                    '${TimecodeFormatter.formatTimecode(currentPosMs, fps: project.fps)} / ${TimecodeFormatter.formatTimecode(totalDurationMs, fps: project.fps)}',
                    style: AppTypography.timecode.copyWith(fontSize: 12, color: AppColors.primaryLight),
                  ),
                ),

                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Safe Margin Guide Toggle
                    InkWell(
                      onTap: () => setState(() => _showSafeMargins = !_showSafeMargins),
                      borderRadius: BorderRadius.circular(6),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: _showSafeMargins
                              ? AppColors.primary.withValues(alpha: 0.3)
                              : Colors.black.withValues(alpha: 0.7),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(
                            color: _showSafeMargins ? AppColors.primaryLight : Colors.white12,
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.grid_3x3,
                              size: 14,
                              color: _showSafeMargins ? Colors.white : AppColors.textMuted,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              'Guides',
                              style: AppTypography.labelSmall.copyWith(
                                color: _showSafeMargins ? Colors.white : AppColors.textMuted,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),

                    // Full Screen Preview Button ⛶
                    InkWell(
                      onTap: _openFullScreenPreview,
                      borderRadius: BorderRadius.circular(6),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFF00C2CB).withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: const Color(0xFF00C2CB), width: 1.2),
                        ),
                        child: const Row(
                          children: [
                            Icon(Icons.fullscreen, size: 16, color: Color(0xFF00C2CB)),
                            SizedBox(width: 4),
                            Text(
                              'Full Screen',
                              style: TextStyle(
                                color: Color(0xFF00C2CB),
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Bottom Floating Playback Controls
          Positioned(
            bottom: 8,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: AppColors.surfaceElevated.withValues(alpha: 0.9),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: AppColors.surfaceBorder),
                boxShadow: const [
                  BoxShadow(color: Colors.black45, blurRadius: 10, offset: Offset(0, 4)),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Step Back 5s
                  IconButton(
                    icon: const Icon(Icons.replay_5, size: 20),
                    tooltip: 'Back 5s',
                    onPressed: () => widget.controller.seekTo(currentPosMs - 5000),
                    constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                    padding: EdgeInsets.zero,
                  ),
                  // Frame Back (1 frame)
                  IconButton(
                    icon: const Icon(Icons.skip_previous, size: 20),
                    tooltip: 'Previous Frame',
                    onPressed: () => widget.controller.seekTo(currentPosMs - 33),
                    constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                    padding: EdgeInsets.zero,
                  ),
                  const SizedBox(width: 4),
                  // Main Play / Pause Button
                  GestureDetector(
                    onTap: widget.controller.togglePlayPause,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [AppColors.primary, AppColors.primaryDark],
                        ),
                      ),
                      child: Icon(
                        state.isPlaying ? Icons.pause : Icons.play_arrow,
                        size: 24,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(width: 4),
                  // Frame Forward (1 frame)
                  IconButton(
                    icon: const Icon(Icons.skip_next, size: 20),
                    tooltip: 'Next Frame',
                    onPressed: () => widget.controller.seekTo(currentPosMs + 33),
                    constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                    padding: EdgeInsets.zero,
                  ),
                  // Step Forward 5s
                  IconButton(
                    icon: const Icon(Icons.forward_5, size: 20),
                    tooltip: 'Forward 5s',
                    onPressed: () => widget.controller.seekTo(currentPosMs + 5000),
                    constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                    padding: EdgeInsets.zero,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoClipFrame(VideoClipEntity clip, int currentPosMs, bool isSelected) {
    Widget frameContent;
    final path = clip.mediaPath;

    // 1. Real Video Player or Image Renderer
    final videoController = _getVideoController(path);
    if (videoController != null && videoController.value.isInitialized) {
      frameContent = FittedBox(
        fit: BoxFit.cover,
        clipBehavior: Clip.hardEdge,
        child: SizedBox(
          width: videoController.value.size.width,
          height: videoController.value.size.height,
          child: VideoPlayer(videoController),
        ),
      );
    } else if (path.startsWith('assets/')) {
      frameContent = Image.asset(
        path,
        fit: BoxFit.cover,
        errorBuilder: (_, _, _) => _buildFallbackFrame(clip),
      );
    } else if (File(path).existsSync()) {
      frameContent = Image.file(
        File(path),
        fit: BoxFit.cover,
        errorBuilder: (_, _, _) => _buildFallbackFrame(clip),
      );
    } else {
      frameContent = _buildFallbackFrame(clip);
    }

    // 2. Preset LUT Color Filter
    if (clip.filterType != FilterType.none && clip.filterType.colorFilter != null) {
      frameContent = ColorFiltered(
        colorFilter: clip.filterType.colorFilter!,
        child: frameContent,
      );
    }

    // 3. Custom Brightness & Contrast
    if (clip.brightness != 0.0 || clip.contrast != 1.0 || clip.saturation != 1.0) {
      final b = clip.brightness;
      final c = clip.contrast;
      final s = clip.saturation;
      final matrix = <double>[
        c * s, 0, 0, 0, b * 255,
        0, c * s, 0, 0, b * 255,
        0, 0, c * s, 0, b * 255,
        0, 0, 0, 1, 0,
      ];
      frameContent = ColorFiltered(
        colorFilter: ColorFilter.matrix(matrix),
        child: frameContent,
      );
    }

    // 4. Blur Effect
    if (clip.blurSigma > 0.0) {
      frameContent = ImageFiltered(
        imageFilter: ImageFilter.blur(
          sigmaX: clip.blurSigma,
          sigmaY: clip.blurSigma,
          tileMode: TileMode.clamp,
        ),
        child: frameContent,
      );
    }

    // 5. Apply Manual Clip Position (Drag/Pan Offset), Rotation & Zoom Scale
    frameContent = Transform.translate(
      offset: Offset(clip.positionX, clip.positionY),
      child: Transform.rotate(
        angle: clip.rotationDegrees * (3.14159 / 180),
        child: Transform.scale(
          scale: clip.zoomScale,
          child: frameContent,
        ),
      ),
    );

    // 6. Calculate Fade In / Fade Out Progress
    final offsetInClip = currentPosMs - clip.timelineStartMs;
    double fadeOpacity = 1.0;

    if (clip.fadeInDurationMs > 0 && offsetInClip < clip.fadeInDurationMs) {
      fadeOpacity *= (offsetInClip / clip.fadeInDurationMs).clamp(0.0, 1.0);
    }

    final remainingMs = clip.effectiveDurationMs - offsetInClip;
    if (clip.fadeOutDurationMs > 0 && remainingMs < clip.fadeOutDurationMs) {
      fadeOpacity *= (remainingMs / clip.fadeOutDurationMs).clamp(0.0, 1.0);
    }

    // 7. Transition Entrance Effect
    if (clip.transitionIn != TransitionType.none && offsetInClip < clip.transitionDurationMs) {
      final transProgress = (offsetInClip / clip.transitionDurationMs).clamp(0.0, 1.0);
      switch (clip.transitionIn) {
        case TransitionType.crossFade:
          fadeOpacity *= transProgress;
          break;
        case TransitionType.zoomIn:
          final scale = 0.5 + (0.5 * transProgress);
          frameContent = Transform.scale(scale: scale, child: frameContent);
          break;
        case TransitionType.wipeRight:
          frameContent = ClipRect(
            child: Align(
              alignment: Alignment.centerLeft,
              widthFactor: transProgress,
              child: frameContent,
            ),
          );
          break;
        case TransitionType.glitch:
          fadeOpacity *= (transProgress > 0.5 ? 1.0 : 0.6);
          break;
        default:
          break;
      }
    }

    if (fadeOpacity < 1.0) {
      frameContent = Opacity(
        opacity: fadeOpacity.clamp(0.0, 1.0),
        child: frameContent,
      );
    }

    // 8. Real CapCut-style Visual Video Effects
    if (clip.effectType != VideoEffectType.none) {
      frameContent = _applyVideoEffect(
        content: frameContent,
        effect: clip.effectType,
        intensity: clip.effectIntensity,
        offsetInClipMs: offsetInClip,
      );
    }

    return frameContent;
  }

  Widget _applyVideoEffect({
    required Widget content,
    required VideoEffectType effect,
    required double intensity,
    required int offsetInClipMs,
  }) {
    switch (effect) {
      case VideoEffectType.flash:
        // High-speed bright luminous white strobe
        final flashCycle = offsetInClipMs % 350;
        final isFlashing = flashCycle < 120;
        final flashAlpha = isFlashing ? (1.0 - (flashCycle / 120.0)) * 0.9 * intensity : 0.0;
        return Stack(
          fit: StackFit.expand,
          children: [
            content,
            if (flashAlpha > 0.01)
              Container(color: Colors.white.withValues(alpha: flashAlpha.clamp(0.0, 1.0))),
          ],
        );

      case VideoEffectType.blackFlash2:
        // Rhythmic dark beat strobe flash
        final bCycle = offsetInClipMs % 450;
        final isBFlashing = bCycle < 150;
        final bAlpha = isBFlashing ? (1.0 - (bCycle / 150.0)) * 0.95 * intensity : 0.0;
        return Stack(
          fit: StackFit.expand,
          children: [
            content,
            if (bAlpha > 0.01)
              Container(color: Colors.black.withValues(alpha: bAlpha.clamp(0.0, 1.0))),
          ],
        );

      case VideoEffectType.shake:
        // Dynamic jitter camera shake
        final t = offsetInClipMs / 50.0;
        final dx = sin(t * 8.3) * 9.0 * intensity;
        final dy = cos(t * 11.7) * 7.0 * intensity;
        final rot = sin(t * 6.1) * 0.035 * intensity;
        return Transform.translate(
          offset: Offset(dx, dy),
          child: Transform.rotate(
            angle: rot,
            child: content,
          ),
        );

      case VideoEffectType.superLarge:
        // Cinematic breathing zoom with pulse
        final pulse = 1.0 + (0.22 * (sin(offsetInClipMs / 300.0).abs()) * intensity);
        return Transform.scale(
          scale: pulse,
          child: content,
        );

      case VideoEffectType.rollingFilm:
        // 35mm film border with vertical moving sprockets & vintage tone
        return Stack(
          fit: StackFit.expand,
          children: [
            ColorFiltered(
              colorFilter: const ColorFilter.matrix(<double>[
                1.15, 0.05, 0.0, 0.0, 10,
                0.05, 0.95, 0.0, 0.0, 5,
                0.0, 0.05, 0.75, 0.0, -10,
                0.0, 0.0, 0.0, 1.0, 0,
              ]),
              child: content,
            ),
            CustomPaint(
              painter: _RollingFilmEffectPainter(offsetMs: offsetInClipMs),
              size: Size.infinite,
            ),
          ],
        );

      case VideoEffectType.explosion:
        // Fiery expanding golden shockwave particles
        return Stack(
          fit: StackFit.expand,
          children: [
            content,
            CustomPaint(
              painter: _ExplosionEffectPainter(
                offsetMs: offsetInClipMs,
                intensity: intensity,
              ),
              size: Size.infinite,
            ),
          ],
        );

      case VideoEffectType.glitch:
        // Chromatic aberration RGB split & horizontal glitch displacement
        final glitchCycle = (offsetInClipMs ~/ 100) % 5 == 0;
        final glitchShift = glitchCycle ? (sin(offsetInClipMs / 25.0) * 10.0 * intensity) : 0.0;
        return Stack(
          fit: StackFit.expand,
          children: [
            if (glitchCycle)
              Transform.translate(
                offset: Offset(-glitchShift, 0),
                child: ColorFiltered(
                  colorFilter: const ColorFilter.mode(Color(0x8800FFFF), BlendMode.screen),
                  child: content,
                ),
              ),
            Transform.translate(
              offset: Offset(glitchShift * 0.5, 0),
              child: content,
            ),
            if (glitchCycle)
              Transform.translate(
                offset: Offset(glitchShift, 0),
                child: ColorFiltered(
                  colorFilter: const ColorFilter.mode(Color(0x88FF0055), BlendMode.screen),
                  child: content,
                ),
              ),
          ],
        );

      case VideoEffectType.neonGlow:
        // Cyberpunk saturated edge neon shine
        return Stack(
          fit: StackFit.expand,
          children: [
            ColorFiltered(
              colorFilter: const ColorFilter.matrix(<double>[
                1.4, 0.0, 0.2, 0.0, 20,
                0.0, 1.3, 0.2, 0.0, 15,
                0.2, 0.0, 1.7, 0.0, 30,
                0.0, 0.0, 0.0, 1.0, 0,
              ]),
              child: content,
            ),
            Container(
              decoration: BoxDecoration(
                border: Border.all(
                  color: const Color(0xFF00F2FE).withValues(alpha: 0.5 * intensity),
                  width: 3.5,
                ),
              ),
            ),
          ],
        );

      case VideoEffectType.retroVhs:
        // Vintage 90s CRT scanlines & VHS timestamp
        return Stack(
          fit: StackFit.expand,
          children: [
            content,
            CustomPaint(
              painter: _VhsScanlinesPainter(offsetMs: offsetInClipMs),
              size: Size.infinite,
            ),
            Positioned(
              top: 10,
              left: 10,
              child: Text(
                'PLAY ▶ SP 00:${(offsetInClipMs ~/ 1000).toString().padLeft(2, '0')}:${((offsetInClipMs % 1000) ~/ 10).toString().padLeft(2, '0')}',
                style: const TextStyle(
                  color: Color(0xFF38EF7D),
                  fontFamily: 'monospace',
                  fontWeight: FontWeight.bold,
                  fontSize: 11,
                  shadows: [Shadow(color: Colors.black, blurRadius: 4)],
                ),
              ),
            ),
          ],
        );

      case VideoEffectType.sparkles:
        // Glittering starlight sparkles
        return Stack(
          fit: StackFit.expand,
          children: [
            content,
            CustomPaint(
              painter: _SparklesEffectPainter(
                offsetMs: offsetInClipMs,
                intensity: intensity,
              ),
              size: Size.infinite,
            ),
          ],
        );

      case VideoEffectType.heartFloat:
        // Floating romantic hearts
        return Stack(
          fit: StackFit.expand,
          children: [
            content,
            CustomPaint(
              painter: _HeartsEffectPainter(
                offsetMs: offsetInClipMs,
                intensity: intensity,
              ),
              size: Size.infinite,
            ),
          ],
        );

      case VideoEffectType.heartbeatZoom:
        // Rhythmic bass pulse
        final beat = 1.0 + (0.15 * pow(sin(offsetInClipMs / 180.0).abs(), 3) * intensity);
        return Transform.scale(scale: beat, child: content);

      case VideoEffectType.kaleidoscope:
        // Multi-angle prism mirror
        return Stack(
          fit: StackFit.expand,
          children: [
            content,
            Transform.scale(
              scaleX: -1.0,
              child: Opacity(
                opacity: 0.35 * intensity,
                child: content,
              ),
            ),
          ],
        );

      case VideoEffectType.fadeIn:
        final inProgress = (offsetInClipMs / 1500.0).clamp(0.0, 1.0);
        return Opacity(
          opacity: inProgress,
          child: content,
        );

      case VideoEffectType.none:
        return content;
    }
  }

  Widget _buildSelectionTransformHandles(VideoClipEntity clip) {
    return IgnorePointer(
      child: Transform.translate(
        offset: Offset(clip.positionX, clip.positionY),
        child: Transform.rotate(
          angle: clip.rotationDegrees * (3.14159 / 180),
          child: Transform.scale(
            scale: clip.zoomScale,
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(color: AppColors.primaryLight, width: 2.0),
              ),
              child: Stack(
                children: [
                  _buildCornerHandle(Alignment.topLeft, AppColors.primary),
                  _buildCornerHandle(Alignment.topRight, AppColors.primary),
                  _buildCornerHandle(Alignment.bottomLeft, AppColors.primary),
                  _buildCornerHandle(Alignment.bottomRight, AppColors.primary),
                  // Top Rotate Pin Anchor
                  Align(
                    alignment: Alignment.topCenter,
                    child: FractionalTranslation(
                      translation: const Offset(0, -1.2),
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: AppColors.primary,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.rotate_right, color: Colors.white, size: 14),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildClipQuickToolbar(VideoClipEntity clip) {
    return Positioned(
      top: 12,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 320),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color: const Color(0xFF1E2028).withValues(alpha: 0.94),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.primaryLight, width: 1.2),
          boxShadow: const [
            BoxShadow(color: Colors.black54, blurRadius: 10, offset: Offset(0, 3)),
          ],
        ),
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Zoom Out
              InkWell(
                onTap: () => widget.controller.zoomClipOut(clip.id),
                child: const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                  child: Row(
                    children: [
                      Icon(Icons.zoom_out, size: 14, color: Colors.white),
                      SizedBox(width: 2),
                      Text('Zoom -', style: TextStyle(color: Colors.white, fontSize: 10.5)),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 2),
              // Zoom Level Label
              Text(
                '${(clip.zoomScale * 100).toInt()}%',
                style: const TextStyle(color: AppColors.primaryLight, fontSize: 10.5, fontWeight: FontWeight.bold),
              ),
              const SizedBox(width: 2),
              // Zoom In
              InkWell(
                onTap: () => widget.controller.zoomClipIn(clip.id),
                child: const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                  child: Row(
                    children: [
                      Icon(Icons.zoom_in, size: 14, color: Colors.white),
                      SizedBox(width: 2),
                      Text('Zoom +', style: TextStyle(color: Colors.white, fontSize: 10.5)),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 4),
              const Text('|', style: TextStyle(color: Colors.white24)),
              const SizedBox(width: 4),
              // Rotate 90
              InkWell(
                onTap: () => widget.controller.rotateClip90(clip.id),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                  child: Row(
                    children: [
                      const Icon(Icons.rotate_90_degrees_ccw, size: 14, color: AppColors.secondary),
                      const SizedBox(width: 2),
                      Text('${clip.rotationDegrees.toInt()}°', style: const TextStyle(color: Colors.white, fontSize: 10.5)),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 4),
              // Reset
              InkWell(
                onTap: () => widget.controller.resetClipTransform(clip.id),
                child: const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                  child: Icon(Icons.restart_alt, size: 15, color: Colors.amber),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInteractiveTextOverlay({
    required TextOverlayEntity textEntity,
    required int currentPosMs,
    required bool isSelected,
    required double canvasWidth,
    required double canvasHeight,
  }) {
    final offsetInText = currentPosMs - textEntity.timelineStartMs;

    double opacity = 1.0;
    double translateY = 0.0;
    const animDurationMs = 500;

    if (offsetInText < animDurationMs) {
      final progress = (offsetInText / animDurationMs).clamp(0.0, 1.0);
      switch (textEntity.animationType) {
        case OverlayAnimationType.fadeIn:
          opacity = progress;
          break;
        case OverlayAnimationType.slideUp:
          translateY = (1.0 - progress) * 40.0;
          opacity = progress;
          break;
        case OverlayAnimationType.bounce:
          translateY = (1.0 - progress) * 20.0;
          break;
        default:
          break;
      }
    }

    String displayText = textEntity.text;
    if (textEntity.animationType == OverlayAnimationType.typewriter) {
      final totalChars = textEntity.text.length;
      final charProgress = (offsetInText / (animDurationMs * 2)).clamp(0.0, 1.0);
      final visibleChars = (totalChars * charProgress).toInt();
      displayText = textEntity.text.substring(0, visibleChars.clamp(0, totalChars));
    }

    return Positioned(
      left: 0,
      right: 0,
      top: 0,
      bottom: 0,
      child: Align(
        alignment: Alignment(
          (textEntity.posX - 0.5) * 2,
          (textEntity.posY - 0.5) * 2,
        ),
        child: GestureDetector(
          onTap: () {
            widget.controller.setSelection(SelectionType.textOverlay, textEntity.id);
          },
          onDoubleTap: () => _openTextEditor(textEntity),
          onScaleStart: (details) {
            _baseTextPosX = textEntity.posX;
            _baseTextPosY = textEntity.posY;
            _baseTextScale = textEntity.scale;
            _baseTextRotation = textEntity.rotation;
          },
          onScaleUpdate: (details) {
            final deltaNormX = details.focalPointDelta.dx / (canvasWidth > 0 ? canvasWidth : 300);
            final deltaNormY = details.focalPointDelta.dy / (canvasHeight > 0 ? canvasHeight : 500);

            final newX = (_baseTextPosX + deltaNormX).clamp(0.05, 0.95);
            final newY = (_baseTextPosY + deltaNormY).clamp(0.05, 0.95);
            final newScale = (_baseTextScale * details.scale).clamp(0.3, 4.0);
            final newRotation = _baseTextRotation + details.rotation;

            _baseTextPosX = newX;
            _baseTextPosY = newY;

            widget.controller.updateTextTransform(
              textId: textEntity.id,
              posX: newX,
              posY: newY,
              scale: newScale,
              rotation: newRotation,
            );
          },
          child: Transform.translate(
            offset: Offset(0, translateY),
            child: Transform.rotate(
              angle: textEntity.rotation,
              child: Transform.scale(
                scale: textEntity.scale,
                child: Opacity(
                  opacity: opacity,
                  child: Stack(
                    clipBehavior: Clip.none,
                    alignment: Alignment.center,
                    children: [
                      // Text Container Box
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: textEntity.backgroundColorHex != null
                              ? Color(textEntity.backgroundColorHex!)
                              : null,
                          borderRadius: BorderRadius.circular(6),
                          border: isSelected
                              ? Border.all(color: AppColors.textTrack, width: 1.5)
                              : null,
                        ),
                        child: Text(
                          displayText,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontFamily: textEntity.fontFamily,
                            fontSize: textEntity.fontSize,
                            fontWeight: FontWeight.bold,
                            color: Color(textEntity.colorHex),
                            shadows: [
                              if (textEntity.outlineColorHex != null)
                                Shadow(
                                  color: Color(textEntity.outlineColorHex!),
                                  blurRadius: textEntity.outlineWidth * 2,
                                ),
                              const Shadow(color: Colors.black87, blurRadius: 8, offset: Offset(1, 2)),
                            ],
                          ),
                        ),
                      ),

                      // Text Selection Handles & Mini Action Floating Bar
                      if (isSelected) ...[
                        _buildCornerHandle(Alignment.topLeft, AppColors.textTrack),
                        _buildCornerHandle(Alignment.topRight, AppColors.textTrack),
                        _buildCornerHandle(Alignment.bottomLeft, AppColors.textTrack),
                        _buildCornerHandle(Alignment.bottomRight, AppColors.textTrack),

                        // Top Floating Action Quick Bar (Edit | Duplicate | Delete)
                        Positioned(
                          top: -36,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: const Color(0xFF1E2028),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: AppColors.textTrack, width: 1),
                              boxShadow: const [
                                BoxShadow(color: Colors.black54, blurRadius: 8, offset: Offset(0, 2)),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                InkWell(
                                  onTap: () => _openTextEditor(textEntity),
                                  child: const Padding(
                                    padding: EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                                    child: Icon(Icons.edit, size: 14, color: Colors.white),
                                  ),
                                ),
                                const SizedBox(width: 4),
                                InkWell(
                                  onTap: () => widget.controller.duplicateTextOverlay(textEntity.id),
                                  child: const Padding(
                                    padding: EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                                    child: Icon(Icons.copy, size: 14, color: AppColors.secondary),
                                  ),
                                ),
                                const SizedBox(width: 4),
                                InkWell(
                                  onTap: () => widget.controller.deleteSelected(),
                                  child: const Padding(
                                    padding: EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                                    child: Icon(Icons.delete_outline, size: 14, color: AppColors.error),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCornerHandle(Alignment alignment, Color color) {
    return Align(
      alignment: alignment,
      child: Container(
        width: 10,
        height: 10,
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          border: Border.all(color: color, width: 2),
        ),
      ),
    );
  }

  Widget _buildFallbackFrame(VideoClipEntity clip) {
    final gradientColors = _getClipGradient(clip.name);

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: gradientColors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Stack(
        children: [
          CustomPaint(
            painter: _ClipVisualPatternPainter(seed: clip.name.hashCode),
            size: Size.infinite,
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.4),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: const Icon(
                    Icons.movie_filter_rounded,
                    size: 36,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  clip.name,
                  style: AppTypography.titleMedium.copyWith(
                    color: Colors.white,
                    shadows: const [Shadow(color: Colors.black, blurRadius: 8)],
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${clip.speed}x • ${clip.filterType.label}',
                  style: AppTypography.labelSmall.copyWith(
                    color: Colors.white70,
                    shadows: const [Shadow(color: Colors.black, blurRadius: 4)],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyCanvasPlaceholder() {
    return Container(
      color: const Color(0xFF16181F),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.videocam_off_outlined, size: 40, color: AppColors.textMuted),
            const SizedBox(height: 8),
            Text('No Video Clip at Playhead', style: AppTypography.bodySmall),
          ],
        ),
      ),
    );
  }

  Widget _buildSafeMarginsGuide() {
    return IgnorePointer(
      child: Container(
        margin: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.secondary.withValues(alpha: 0.6), width: 1),
        ),
        child: Stack(
          children: [
            Align(
              alignment: Alignment.center,
              child: Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.secondary, width: 1.5),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStickerOverlay(StickerOverlayEntity sticker) {
    return Positioned(
      left: 0,
      right: 0,
      top: 0,
      bottom: 0,
      child: Align(
        alignment: Alignment(
          (sticker.posX - 0.5) * 2,
          (sticker.posY - 0.5) * 2,
        ),
        child: Transform.rotate(
          angle: sticker.rotation,
          child: Transform.scale(
            scale: sticker.scale,
            child: Text(
              sticker.assetEmojiOrPath,
              style: const TextStyle(fontSize: 48),
            ),
          ),
        ),
      ),
    );
  }

  List<Color> _getClipGradient(String name) {
    final code = name.hashCode.abs();
    final paletteIndex = code % 5;
    switch (paletteIndex) {
      case 0:
        return const [Color(0xFF1E3A8A), Color(0xFF065F46), Color(0xFF111827)];
      case 1:
        return const [Color(0xFF581C87), Color(0xFF831843), Color(0xFF0F172A)];
      case 2:
        return const [Color(0xFF7C2D12), Color(0xFF78350F), Color(0xFF18181B)];
      case 3:
        return const [Color(0xFF0F766E), Color(0xFF1E40AF), Color(0xFF020617)];
      default:
        return const [Color(0xFF312E81), Color(0xFF4C1D95), Color(0xFF09090B)];
    }
  }

  void _openFullScreenPreview() {
    Navigator.of(context).push(
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (ctx) => _FullScreenEditorPreviewDialog(
          timelineState: widget.timelineState,
          controller: widget.controller,
          videoController: _currentPlayingPath != null ? _videoControllers[_currentPlayingPath] : null,
          buildVideoFrame: (clip, pos, isSel) => _buildVideoClipFrame(clip, pos, isSel),
        ),
      ),
    );
  }
}

class _ClipVisualPatternPainter extends CustomPainter {
  final int seed;
  _ClipVisualPatternPainter({required this.seed});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withValues(alpha: 0.05)
      ..strokeWidth = 1.0;

    for (int i = 0; i < size.width; i += 30) {
      canvas.drawLine(Offset(i.toDouble(), 0), Offset(i.toDouble(), size.height), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _ClipVisualPatternPainter oldDelegate) =>
      oldDelegate.seed != seed;
}

/// Rolling 35mm film border with vertical moving sprockets
class _RollingFilmEffectPainter extends CustomPainter {
  final int offsetMs;
  _RollingFilmEffectPainter({required this.offsetMs});

  @override
  void paint(Canvas canvas, Size size) {
    const sprocketWidth = 16.0;
    const sprocketHeight = 12.0;
    const sprocketGap = 16.0;
    final totalH = sprocketHeight + sprocketGap;
    final scrollY = (offsetMs / 40.0) % totalH;

    final borderPaint = Paint()..color = const Color(0xCC000000);
    final holePaint = Paint()..color = const Color(0x99FFFFFF);

    // Left & Right film black borders
    canvas.drawRect(Rect.fromLTWH(0, 0, sprocketWidth + 8, size.height), borderPaint);
    canvas.drawRect(Rect.fromLTWH(size.width - sprocketWidth - 8, 0, sprocketWidth + 8, size.height), borderPaint);

    // Vertical sprocket holes
    for (double y = -totalH + scrollY; y < size.height + totalH; y += totalH) {
      // Left hole
      final leftRRect = RRect.fromRectAndRadius(
        Rect.fromLTWH(4, y, sprocketWidth, sprocketHeight),
        const Radius.circular(3),
      );
      canvas.drawRRect(leftRRect, holePaint);

      // Right hole
      final rightRRect = RRect.fromRectAndRadius(
        Rect.fromLTWH(size.width - sprocketWidth - 4, y, sprocketWidth, sprocketHeight),
        const Radius.circular(3),
      );
      canvas.drawRRect(rightRRect, holePaint);
    }
  }

  @override
  bool shouldRepaint(covariant _RollingFilmEffectPainter oldDelegate) => true;
}

/// Fiery golden explosion particle blast
class _ExplosionEffectPainter extends CustomPainter {
  final int offsetMs;
  final double intensity;

  _ExplosionEffectPainter({required this.offsetMs, required this.intensity});

  @override
  void paint(Canvas canvas, Size size) {
    final cycle = (offsetMs % 1200) / 1200.0;
    final center = Offset(size.width / 2, size.height / 2);
    final maxRadius = (size.width / 2) * 1.2;

    // Expanding shockwave ring
    final shockRadius = maxRadius * cycle;
    final ringPaint = Paint()
      ..color = const Color(0xFFFF9900).withValues(alpha: (1.0 - cycle) * 0.7 * intensity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 6.0 * (1.0 - cycle);
    canvas.drawCircle(center, shockRadius, ringPaint);

    // Blast particle rays
    const particleCount = 20;
    final particlePaint = Paint()..style = PaintingStyle.fill;

    for (int i = 0; i < particleCount; i++) {
      final angle = (i * (2 * pi / particleCount)) + (cycle * 0.5);
      final dist = shockRadius * (0.6 + 0.4 * sin(i * 1.5).abs());
      final px = center.dx + cos(angle) * dist;
      final py = center.dy + sin(angle) * dist;
      final pRadius = (1.0 - cycle) * (5.0 + (i % 4) * 2) * intensity;

      particlePaint.color = i % 2 == 0
          ? const Color(0xFFFFD200).withValues(alpha: (1.0 - cycle) * 0.85)
          : const Color(0xFFFF3300).withValues(alpha: (1.0 - cycle) * 0.75);

      canvas.drawCircle(Offset(px, py), pRadius, particlePaint);
    }
  }

  @override
  bool shouldRepaint(covariant _ExplosionEffectPainter oldDelegate) => true;
}

/// CRT Scanlines and horizontal scanline noise
class _VhsScanlinesPainter extends CustomPainter {
  final int offsetMs;
  _VhsScanlinesPainter({required this.offsetMs});

  @override
  void paint(Canvas canvas, Size size) {
    final linePaint = Paint()
      ..color = Colors.black.withValues(alpha: 0.18)
      ..strokeWidth = 1.0;

    for (double y = 0; y < size.height; y += 4.0) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), linePaint);
    }

    // Moving tracking horizontal noise bar
    final barY = (offsetMs / 5.0) % size.height;
    final noisePaint = Paint()
      ..color = Colors.white.withValues(alpha: 0.08)
      ..strokeWidth = 12.0;
    canvas.drawLine(Offset(0, barY), Offset(size.width, barY), noisePaint);
  }

  @override
  bool shouldRepaint(covariant _VhsScanlinesPainter oldDelegate) => true;
}

/// Glittering starlight sparkles
class _SparklesEffectPainter extends CustomPainter {
  final int offsetMs;
  final double intensity;

  _SparklesEffectPainter({required this.offsetMs, required this.intensity});

  @override
  void paint(Canvas canvas, Size size) {
    final t = offsetMs / 1000.0;
    const count = 12;
    final paint = Paint()
      ..color = const Color(0xFFFFE066)
      ..style = PaintingStyle.fill;

    for (int i = 0; i < count; i++) {
      final randX = ((i * 73 + 17) % 100) / 100.0 * size.width;
      final randY = ((i * 47 + 31) % 100) / 100.0 * size.height;
      final sparklePhase = sin(t * 5.0 + i * 1.3).abs();
      final radius = sparklePhase * 6.0 * intensity;

      if (radius > 0.5) {
        paint.color = Color.lerp(const Color(0xFFFFD700), Colors.white, sparklePhase)!
            .withValues(alpha: sparklePhase * 0.85);

        // 4-point star
        final path = Path();
        path.moveTo(randX, randY - radius * 2);
        path.lineTo(randX + radius * 0.5, randY - radius * 0.5);
        path.lineTo(randX + radius * 2, randY);
        path.lineTo(randX + radius * 0.5, randY + radius * 0.5);
        path.lineTo(randX, randY + radius * 2);
        path.lineTo(randX - radius * 0.5, randY + radius * 0.5);
        path.lineTo(randX - radius * 2, randY);
        path.lineTo(randX - radius * 0.5, randY - radius * 0.5);
        path.close();
        canvas.drawPath(path, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _SparklesEffectPainter oldDelegate) => true;
}

/// Floating romantic heart particles
class _HeartsEffectPainter extends CustomPainter {
  final int offsetMs;
  final double intensity;

  _HeartsEffectPainter({required this.offsetMs, required this.intensity});

  @override
  void paint(Canvas canvas, Size size) {
    const count = 8;
    final paint = Paint()..style = PaintingStyle.fill;

    for (int i = 0; i < count; i++) {
      final speed = 0.0008 + (i % 3) * 0.0003;
      final yProgress = (1.0 - ((offsetMs * speed + (i / count.toDouble())) % 1.0));
      final py = yProgress * size.height;
      final px = (0.2 + 0.6 * ((i * 37) % 100 / 100.0) + sin(offsetMs / 300.0 + i) * 0.06) * size.width;
      final scale = (0.8 + 0.4 * sin(i.toDouble())) * intensity;
      final alpha = (yProgress < 0.2 ? yProgress / 0.2 : (yProgress > 0.8 ? (1.0 - yProgress) / 0.2 : 1.0)) * 0.85;

      paint.color = const Color(0xFFFF416C).withValues(alpha: alpha.clamp(0.0, 1.0));

      final path = Path();
      final w = 14.0 * scale;
      final h = 14.0 * scale;
      path.moveTo(px, py + h * 0.3);
      path.cubicTo(px, py, px - w * 0.5, py, px - w * 0.5, py + h * 0.3);
      path.cubicTo(px - w * 0.5, py + h * 0.6, px, py + h * 0.85, px, py + h);
      path.cubicTo(px, py + h * 0.85, px + w * 0.5, py + h * 0.6, px + w * 0.5, py + h * 0.3);
      path.cubicTo(px + w * 0.5, py, px, py, px, py + h * 0.3);
      path.close();

      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _HeartsEffectPainter oldDelegate) => true;
}

/// Immersive, Edge-to-Edge Full Screen Video Editor Preview Modal
class _FullScreenEditorPreviewDialog extends StatefulWidget {
  final TimelineState timelineState;
  final EditorController controller;
  final VideoPlayerController? videoController;
  final Widget Function(VideoClipEntity clip, int currentPosMs, bool isSelected) buildVideoFrame;

  const _FullScreenEditorPreviewDialog({
    required this.timelineState,
    required this.controller,
    required this.videoController,
    required this.buildVideoFrame,
  });

  @override
  State<_FullScreenEditorPreviewDialog> createState() => _FullScreenEditorPreviewDialogState();
}

class _FullScreenEditorPreviewDialogState extends State<_FullScreenEditorPreviewDialog> {
  bool _showControls = true;

  @override
  Widget build(BuildContext context) {
    final state = widget.timelineState;
    final project = state.project;
    final activeClip = state.activeVideoClip;
    final currentPosMs = state.playheadPositionMs;
    final totalDurationMs = project.calculatedDurationMs;

    // Filter active text overlays
    final activeTexts = project.textOverlays.where((t) {
      return currentPosMs >= t.timelineStartMs && currentPosMs <= t.timelineEndMs;
    }).toList();

    // Filter active sticker overlays
    final activeStickers = project.stickerOverlays.where((s) {
      return currentPosMs >= s.timelineStartMs && currentPosMs <= s.timelineEndMs;
    }).toList();

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => setState(() => _showControls = !_showControls),
        child: Stack(
          fit: StackFit.expand,
          children: [
            // 1. Centered True Aspect-Ratio Canvas Layer
            Center(
              child: AspectRatio(
                aspectRatio: project.aspectRatio.ratio,
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final canvasWidth = constraints.maxWidth;

                    return Container(
                      color: Colors.black,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          if (activeClip != null)
                            widget.buildVideoFrame(activeClip, currentPosMs, false)
                          else
                            Container(
                              color: const Color(0xFF16181F),
                              child: const Center(
                                child: Text('No Clip at Playhead', style: TextStyle(color: Colors.white54)),
                              ),
                            ),

                          // Text Overlays
                          ...activeTexts.map((textEntity) {
                            final offsetInText = currentPosMs - textEntity.timelineStartMs;
                            double opacity = 1.0;
                            double translateY = 0.0;
                            const animDurationMs = 500;

                            if (offsetInText < animDurationMs) {
                              final progress = (offsetInText / animDurationMs).clamp(0.0, 1.0);
                              if (textEntity.animationType == OverlayAnimationType.fadeIn) {
                                opacity = progress;
                              } else if (textEntity.animationType == OverlayAnimationType.slideUp) {
                                translateY = (1.0 - progress) * 40.0;
                                opacity = progress;
                              }
                            }

                            return Positioned(
                              left: 0,
                              right: 0,
                              top: 0,
                              bottom: 0,
                              child: Align(
                                alignment: Alignment(
                                  (textEntity.posX - 0.5) * 2,
                                  (textEntity.posY - 0.5) * 2,
                                ),
                                child: Transform.translate(
                                  offset: Offset(0, translateY),
                                  child: Transform.rotate(
                                    angle: textEntity.rotation,
                                    child: Transform.scale(
                                      scale: textEntity.scale,
                                      child: Opacity(
                                        opacity: opacity,
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                          decoration: BoxDecoration(
                                            color: textEntity.backgroundColorHex != null
                                                ? Color(textEntity.backgroundColorHex!)
                                                : null,
                                            borderRadius: BorderRadius.circular(6),
                                          ),
                                          child: Text(
                                            textEntity.text,
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              fontFamily: textEntity.fontFamily,
                                              fontSize: textEntity.fontSize * (canvasWidth / 360.0).clamp(0.8, 2.0),
                                              fontWeight: FontWeight.bold,
                                              color: Color(textEntity.colorHex),
                                              shadows: const [
                                                Shadow(color: Colors.black87, blurRadius: 8, offset: Offset(1, 2)),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            );
                          }),

                          // Sticker Overlays
                          ...activeStickers.map((sticker) {
                            return Positioned(
                              left: 0,
                              right: 0,
                              top: 0,
                              bottom: 0,
                              child: Align(
                                alignment: Alignment(
                                  (sticker.posX - 0.5) * 2,
                                  (sticker.posY - 0.5) * 2,
                                ),
                                child: Transform.rotate(
                                  angle: sticker.rotation,
                                  child: Transform.scale(
                                    scale: sticker.scale,
                                    child: Text(
                                      sticker.assetEmojiOrPath,
                                      style: const TextStyle(fontSize: 48),
                                    ),
                                  ),
                                ),
                              ),
                            );
                          }),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),

            // 2. Animated Overlay Controls (Top minimize bar & Bottom control pill)
            if (_showControls) ...[
              // Top Bar: Project Title, Timecode & Minimize Button
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: Container(
                  padding: const EdgeInsets.only(top: 44, left: 16, right: 16, bottom: 14),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.black87, Colors.transparent],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Project Title & Timecode
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            project.title,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '${TimecodeFormatter.formatTimecode(currentPosMs, fps: project.fps)} / ${TimecodeFormatter.formatTimecode(totalDurationMs, fps: project.fps)}',
                            style: const TextStyle(
                              color: Color(0xFF00C2CB),
                              fontSize: 12,
                              fontFamily: 'monospace',
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),

                      // Minimize / Exit Full Screen Button 🗗
                      InkWell(
                        onTap: () => Navigator.of(context).pop(),
                        borderRadius: BorderRadius.circular(20),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.white24,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: Colors.white30, width: 1.2),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.fullscreen_exit, color: Colors.white, size: 18),
                              SizedBox(width: 4),
                              Text(
                                'Minimize',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Bottom Control Bar with Scrubber & Media Controls
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  padding: const EdgeInsets.only(top: 14, left: 20, right: 20, bottom: 36),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.transparent, Colors.black87, Colors.black],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Interactive Precision Timeline Scrubber Slider
                      SliderTheme(
                        data: SliderTheme.of(context).copyWith(
                          activeTrackColor: const Color(0xFF00C2CB),
                          inactiveTrackColor: Colors.white24,
                          thumbColor: Colors.white,
                          thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                          trackHeight: 3.5,
                          overlayShape: const RoundSliderOverlayShape(overlayRadius: 12),
                        ),
                        child: Slider(
                          value: currentPosMs.toDouble().clamp(0.0, max(1.0, totalDurationMs.toDouble())),
                          min: 0.0,
                          max: max(1.0, totalDurationMs.toDouble()),
                          onChanged: (val) {
                            widget.controller.seekTo(val.toInt());
                          },
                        ),
                      ),
                      const SizedBox(height: 4),

                      // Media Buttons Pill: [ -5s ] [ Skip Prev ] [ ▶ / ⏸ ] [ Skip Next ] [ +5s ]
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.replay_5, color: Colors.white70, size: 26),
                            tooltip: 'Back 5s',
                            onPressed: () => widget.controller.seekTo(currentPosMs - 5000),
                          ),
                          const SizedBox(width: 8),
                          IconButton(
                            icon: const Icon(Icons.skip_previous, color: Colors.white, size: 28),
                            tooltip: 'Previous Frame',
                            onPressed: () => widget.controller.seekTo(currentPosMs - 33),
                          ),
                          const SizedBox(width: 14),
                          GestureDetector(
                            onTap: widget.controller.togglePlayPause,
                            child: Container(
                              padding: const EdgeInsets.all(14),
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: LinearGradient(
                                  colors: [Color(0xFF00C2CB), Color(0xFF00838F)],
                                ),
                              ),
                              child: Icon(
                                state.isPlaying ? Icons.pause : Icons.play_arrow,
                                size: 32,
                                color: Colors.white,
                              ),
                            ),
                          ),
                          const SizedBox(width: 14),
                          IconButton(
                            icon: const Icon(Icons.skip_next, color: Colors.white, size: 28),
                            tooltip: 'Next Frame',
                            onPressed: () => widget.controller.seekTo(currentPosMs + 33),
                          ),
                          const SizedBox(width: 8),
                          IconButton(
                            icon: const Icon(Icons.forward_5, color: Colors.white70, size: 26),
                            tooltip: 'Forward 5s',
                            onPressed: () => widget.controller.seekTo(currentPosMs + 5000),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
